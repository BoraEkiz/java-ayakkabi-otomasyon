package konsey;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import project.ConnectionProvider;

public class UpdateDeleteMember extends JFrame {

	private JPanel jbutton4;
	private JTextField JtextField;
	private JTextField jtextField2;
	private JTextField jtextField3;
	private JTextField jtextField4;
	private JTextField jtextField5;
	private JTextField jtextField6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateDeleteMember frame = new UpdateDeleteMember();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateDeleteMember() {
		setBackground(new Color(0, 0, 0));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 494);
		jbutton4 = new JPanel();
		jbutton4.setBackground(SystemColor.textHighlight);
		jbutton4.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(jbutton4);
		jbutton4.setLayout(null);
		
		JLabel jLabel2 = new JLabel("GÜNCELLEME VE SİLME İŞLEMİ");
		jLabel2.setBackground(new Color(0, 0, 0));
		jLabel2.setForeground(SystemColor.menu);
		jLabel2.setBounds(166, 10, 378, 60);
		jLabel2.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/resimler/update & delete member.png")));
		jLabel2.setFont(new Font("Unispace", Font.PLAIN, 12));
		jbutton4.add(jLabel2);
		
		JLabel jLabel1 = new JLabel("ID");
		jLabel1.setForeground(SystemColor.menu);
		jLabel1.setBounds(91, 89, 46, 14);
		jbutton4.add(jLabel1);
		
		JtextField = new JTextField();
		JtextField.setBounds(124, 86, 86, 20);
		jbutton4.add(JtextField);
		JtextField.setColumns(10);
		
		JButton jbutton1 = new JButton("ARAMA");
		jbutton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int checkid=0;
				String id=JtextField.getText();
				try
				{
					Connection con=ConnectionProvider.getCon();
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("Select * from veriler where id='"+id+"'");
					while(rs.next())
					{
						checkid=1;
						JtextField.setEditable(false);
						jtextField2.setText(rs.getString(2));
						jtextField3.setText(rs.getString(3));
						jtextField4.setText(rs.getString(4));
						jtextField5.setText(rs.getString(5));
						jtextField6.setText(rs.getString(6));
					
					}
					if(checkid==0)
						JOptionPane.showMessageDialog(null, "Exit");
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e);
					
				}
			}
		});
		jbutton1.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/resimler/search.png")));
		jbutton1.setBounds(233, 85, 109, 23);
		jbutton4.add(jbutton1);
		
		JLabel Jlabel3 = new JLabel("Ürün Adi");
		Jlabel3.setBackground(new Color(0, 0, 0));
		Jlabel3.setForeground(SystemColor.menu);
		Jlabel3.setFont(new Font("Unispace", Font.PLAIN, 12));
		Jlabel3.setBounds(91, 114, 453, 14);
		jbutton4.add(Jlabel3);
		
		jtextField2 = new JTextField();
		jtextField2.setBounds(91, 139, 258, 20);
		jbutton4.add(jtextField2);
		jtextField2.setColumns(10);
		
		JLabel jLabel4 = new JLabel("Ürün Numarası");
		jLabel4.setBackground(new Color(0, 0, 0));
		jLabel4.setForeground(SystemColor.menu);
		jLabel4.setFont(new Font("Unispace", Font.PLAIN, 12));
		jLabel4.setBounds(91, 170, 453, 14);
		jbutton4.add(jLabel4);
		
		jtextField3 = new JTextField();
		jtextField3.setColumns(10);
		jtextField3.setBounds(91, 195, 258, 20);
		jbutton4.add(jtextField3);
		
		JLabel jLabel5 = new JLabel("Ürün Stok Adedi");
		jLabel5.setBackground(new Color(0, 0, 0));
		jLabel5.setForeground(SystemColor.menu);
		jLabel5.setFont(new Font("Unispace", Font.PLAIN, 12));
		jLabel5.setBounds(91, 226, 453, 14);
		jbutton4.add(jLabel5);
		
		jtextField4 = new JTextField();
		jtextField4.setBounds(91, 251, 258, 20);
		jbutton4.add(jtextField4);
		jtextField4.setColumns(10);
		
		JLabel jLabel6 = new JLabel("Ürün Modeli");
		jLabel6.setBackground(new Color(0, 0, 0));
		jLabel6.setForeground(SystemColor.menu);
		jLabel6.setFont(new Font("Unispace", Font.PLAIN, 12));
		jLabel6.setBounds(91, 282, 453, 14);
		jbutton4.add(jLabel6);
		
		jtextField5 = new JTextField();
		jtextField5.setColumns(10);
		jtextField5.setBounds(91, 307, 258, 20);
		jbutton4.add(jtextField5);
		
		JButton jbutton2 = new JButton("Güncelle");
		jbutton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=JtextField.getText();
				String ad=jtextField2.getText();
				String ürünnumarası=jtextField3.getText();
				String Stokadedi=jtextField4.getText();
				String ÜrünModeli=jtextField5.getText();
				String ÜrünFiyati=jtextField6.getText();
				
				try {
					Connection con=ConnectionProvider.getCon();					
					PreparedStatement ps=con.prepareStatement("update veriler set ad=? ,ürünnumarası=?,Stokadedi=?,ÜrünModeli=?,ÜrünFiyati=? ");
					ps.setString(1, ad);
					ps.setString(1, ürünnumarası);
					ps.setString(1, Stokadedi);
					ps.setString(1, ÜrünModeli);
					ps.setString(1, ÜrünFiyati);
					JOptionPane.showMessageDialog(null, "Güncelleme Yapıldı");
					setVisible(true);
					new UpdateDeleteMember().setVisible(true);
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
				
				
				
			}
		});
		jbutton2.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/resimler/save.png")));
		jbutton2.setBounds(113, 402, 97, 23);
		jbutton4.add(jbutton2);
		
		JButton btnNewButton_1_1_1 = new JButton("Sıfırla");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				new UpdateDeleteMember().setVisible(true);
			}
		});
		btnNewButton_1_1_1.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/resimler/reset.png")));
		btnNewButton_1_1_1.setBounds(232, 402, 97, 23);
		jbutton4.add(btnNewButton_1_1_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/resimler/pngwing.com (2).png")));
		lblNewLabel.setBounds(359, 0, 324, 455);
		jbutton4.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			setVisible(false);
			new home().setVisible(true);
				
				
			}
		});
		btnNewButton.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/resimler/close.png")));
		btnNewButton.setBackground(SystemColor.textHighlight);
		btnNewButton.setBounds(10, 10, 89, 23);
		jbutton4.add(btnNewButton);
		
		JLabel jLabel7 = new JLabel("Ürün Fiyatı");
		jLabel7.setForeground(SystemColor.menu);
		jLabel7.setFont(new Font("Unispace", Font.PLAIN, 12));
		jLabel7.setBackground(Color.BLACK);
		jLabel7.setBounds(91, 338, 258, 14);
		jbutton4.add(jLabel7);
		
		jtextField6 = new JTextField();
		jtextField6.setColumns(10);
		jtextField6.setBounds(91, 363, 258, 20);
		jbutton4.add(jtextField6);
	}
}
