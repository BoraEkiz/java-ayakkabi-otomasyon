package konsey;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home frame = new home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public home() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu JMenu1 = new JMenu("Ayakkabıekle");
		JMenu1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
									
					setVisible(false);
					new NewMember().setVisible(true);
				
		
				
				
				
			}
		});
		JMenu1.setFont(new Font("Unispace", Font.PLAIN, 14));
		JMenu1.setIcon(new ImageIcon(home.class.getResource("/resimler/new member.png")));
		JMenu1.setForeground(new Color(0, 0, 0));
		menuBar.add(JMenu1);
		
		JMenu JMenu2 = new JMenu("Sil ve Güncelle");
		JMenu2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) 
			{
				setVisible(false);
				new UpdateDeleteMember().setVisible(true);
			}
		});
		JMenu2.setFont(new Font("Unispace", Font.PLAIN, 14));
		JMenu2.setIcon(new ImageIcon(home.class.getResource("/resimler/update & delete member.png")));
		menuBar.add(JMenu2);
		
		JMenu JMenu3 = new JMenu("AyakkabıListele");
		JMenu3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				setVisible(false);
				new ListOfMember().setVisible(true);
				
			}
		});
		JMenu3.setFont(new Font("Unispace", Font.PLAIN, 14));
		JMenu3.setIcon(new ImageIcon(home.class.getResource("/resimler/list of members.png")));
		menuBar.add(JMenu3);
		
		JMenu JMenu4 = new JMenu("ÇIKIŞ");
		JMenu4.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				
				int a=JOptionPane.showConfirmDialog(null, "Kapatmak istermisiniz","evet",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{													
					setVisible(false);
					new login().setVisible(true);
				}
					
				
			}
		});
		JMenu4.setFont(new Font("Unispace", Font.PLAIN, 14));
		JMenu4.setIcon(new ImageIcon(home.class.getResource("/resimler/exit.png")));
		menuBar.add(JMenu4);
		
		JMenu JMenu5 = new JMenu("KAPATMA");
		JMenu5.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				System.exit(0);
				
			}
		});
		JMenu5.setFont(new Font("Unispace", Font.PLAIN, 14));
		JMenu5.setIcon(new ImageIcon(home.class.getResource("/resimler/logout.png")));
		menuBar.add(JMenu5);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(30, 144, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(100, 149, 237));
		panel.setBounds(10, 0, 1350, 866);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel Jlabel1 = new JLabel("HOŞGELDİNİZ");
		Jlabel1.setBounds(434, 314, 341, 61);
		panel.add(Jlabel1);
		Jlabel1.setFont(new Font("Unispace", Font.PLAIN, 50));
	}
}
