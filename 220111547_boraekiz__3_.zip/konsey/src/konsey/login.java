package konsey;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.ImageIcon;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField JTexTField1;
	private JPasswordField JtextField2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 702, 421);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.textHighlight);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTexTField1 = new JTextField();
		JTexTField1.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
			
				
			}
			public void focusLost(FocusEvent e) {
			}
		});
		JTexTField1.setBounds(121, 96, 148, 20);
		contentPane.add(JTexTField1);
		JTexTField1.setColumns(10);
		
		JLabel Jlabel1 = new JLabel("KONSEY AYAKKABI");
		Jlabel1.setFont(new Font("Unispace", Font.PLAIN, 20));
		Jlabel1.setBounds(83, 25, 180, 41);
		contentPane.add(Jlabel1);
		
		final JLabel Jlabel2 = new JLabel("Kullanıcı adı ve şifreyi giriniz...");
		Jlabel2.setFont(new Font("Unispace", Font.BOLD, 11));
		Jlabel2.setBounds(46, 71, 255, 14);
		contentPane.add(Jlabel2);
		
		JtextField2 = new JPasswordField();
		JtextField2.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
			}
			public void focusLost(FocusEvent e) {
			}
		});
		JtextField2.setToolTipText("");
		JtextField2.setBounds(121, 139, 148, 20);
		contentPane.add(JtextField2);
		
		JButton btnNewButton = new JButton("GİRİŞ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(JTexTField1.getText().equals("admin") && JtextField2.getText().equals("123"))
					
				{
					setVisible(false);
					new home().setVisible(true);
				}
				else
					Jlabel2.setVisible(true);
				
				
				
			}
		});
		btnNewButton.setBounds(85, 184, 89, 23);
		contentPane.add(btnNewButton);
		
		final JCheckBox jcheckbox1 = new JCheckBox("Şifreyi Göster");
		jcheckbox1.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				if(jcheckbox1.isSelected())
				{
					JtextField2.setEchoChar((char)0);
				}
				else
				{
					JtextField2.setEchoChar('*');
				}
				
			}
		});
		jcheckbox1.setBounds(180, 184, 97, 23);
		contentPane.add(jcheckbox1);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(login.class.getResource("/resimler/pngegg.png")));
		lblNewLabel_2.setBounds(319, 4, 366, 382);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblKullancAd = new JLabel("Kullanıcı Adı:");
		lblKullancAd.setBounds(56, 99, 65, 14);
		contentPane.add(lblKullancAd);
		
		JLabel lblNewLabel_1 = new JLabel("Parola:");
		lblNewLabel_1.setBounds(62, 142, 54, 14);
		contentPane.add(lblNewLabel_1);
	}
}
