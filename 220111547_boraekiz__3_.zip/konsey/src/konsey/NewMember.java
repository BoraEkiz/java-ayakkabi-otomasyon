package konsey;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import project.ConnectionProvider;
import java.sql.*;
public class NewMember extends JFrame {

	private JPanel contentPane;
	private JTextField Jtextfield1;
	private JTextField Jtextfield2;
	private JTextField JtextField3;
	private JTextField jtextField6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewMember frame = new NewMember();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewMember() {
		
		
		
		
		
		
		
		
		
		
		setLocation(new Point(176, 1000));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.textHighlight);
		panel.setBounds(10, 0, 984, 561);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton jButton1 = new JButton("");
		jButton1.setBackground(SystemColor.textHighlight);
		jButton1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				System.exit(0);
			}
		});
		jButton1.setIcon(new ImageIcon(NewMember.class.getResource("/resimler/close.png")));
		jButton1.setBounds(0, 0, 53, 37);
		panel.add(jButton1);
		
		JLabel lblNewLabel = new JLabel("YENİ ÜRÜN GİRİŞİ");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 11));
		lblNewLabel.setIcon(new ImageIcon(NewMember.class.getResource("/resimler/pngwing.com (2).png")));
		lblNewLabel.setBounds(391, 32, 552, 470);
		panel.add(lblNewLabel);
		
		JLabel jLabel2 = new JLabel("Ürünİd:");
		jLabel2.setFont(new Font("Unispace", Font.BOLD, 12));
		jLabel2.setBounds(44, 92, 82, 17);
		panel.add(jLabel2);
		
		final JLabel jLabel3 = new JLabel("00");
		jLabel3.setFont(new Font("Unispace", Font.BOLD, 12));
		jLabel3.setBounds(136, 93, 83, 14);
		panel.add(jLabel3);
		
		JLabel jLabel4 = new JLabel("Ürün Adı");
		jLabel4.setFont(new Font("Unispace", Font.BOLD, 12));
		jLabel4.setBounds(44, 120, 68, 14);
		panel.add(jLabel4);
		
		Jtextfield1 = new JTextField();
		Jtextfield1.setFont(new Font("Unispace", Font.BOLD, 14));
		Jtextfield1.setBounds(41, 145, 287, 20);
		panel.add(Jtextfield1);
		Jtextfield1.setColumns(10);
		
		JLabel jLabel5 = new JLabel("Ürün Numarası");
		jLabel5.setFont(new Font("Unispace", Font.BOLD, 12));
		jLabel5.setBounds(41, 176, 156, 14);
		panel.add(jLabel5);
		
		Jtextfield2 = new JTextField();
		Jtextfield2.setFont(new Font("Unispace", Font.BOLD, 14));
		Jtextfield2.setColumns(10);
		Jtextfield2.setBounds(41, 201, 287, 20);
		panel.add(Jtextfield2);
		
		JLabel jLabel6 = new JLabel("Ürün Stok Adedi");
		jLabel6.setFont(new Font("Unispace", Font.BOLD, 12));
		jLabel6.setBounds(44, 232, 125, 14);
		panel.add(jLabel6);
		
		JtextField3 = new JTextField();
		JtextField3.setFont(new Font("Unispace", Font.BOLD, 14));
		JtextField3.setColumns(10);
		JtextField3.setBounds(41, 257, 287, 20);
		panel.add(JtextField3);
		
		JLabel jLabel7 = new JLabel("Ürün Modeli");
		jLabel7.setFont(new Font("Unispace", Font.BOLD, 12));
		jLabel7.setBounds(44, 288, 96, 14);
		panel.add(jLabel7);
		
		final JComboBox jcomboBox1 = new JComboBox();
		jcomboBox1.setModel(new DefaultComboBoxModel(new String[] {"Günlük", "Spor", "Kışlık", "Terlik"}));
		jcomboBox1.setToolTipText("");
		jcomboBox1.setFont(new Font("Unispace", Font.BOLD, 14));
		jcomboBox1.setBounds(44, 313, 284, 22);
		panel.add(jcomboBox1);
		
		
		
		JButton JButton3 = new JButton("TEMİZLE");
		JButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				setVisible(false);
				new NewMember().setVisible(true);
				
				
				
				
			}
		});
		JButton3.setIcon(new ImageIcon(NewMember.class.getResource("/resimler/reset.png")));
		JButton3.setBounds(194, 428, 115, 37);
		panel.add(JButton3);
		
		JLabel jLabel11 = new JLabel("Ürün Fiyatı");
		jLabel11.setFont(new Font("Unispace", Font.BOLD, 12));
		jLabel11.setBounds(44, 346, 125, 14);
		panel.add(jLabel11);
		
		jtextField6 = new JTextField();
		jtextField6.setFont(new Font("Unispace", Font.BOLD, 14));
		jtextField6.setColumns(10);
		jtextField6.setBounds(44, 371, 287, 20);
		panel.add(jtextField6);
		
		
		try 
		{
			int id=1;
			String str1=String.valueOf(id);
			jLabel3.setText(str1);
			Connection con=ConnectionProvider.getCon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select max(id) from veriler");
			while(rs.next()){
				id=rs.getInt(1);
				id=id+1;
				String str=String.valueOf(id);
				jLabel3.setText(str);
			}
		}
		catch(Exception e)
		{
			JOptionPane.showConfirmDialog(null, e);
		}
		
		
		
		JButton JButton2 = new JButton("KAYIT");
		JButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String id=jLabel3.getText();
				String ad=Jtextfield1.getText();
				String ürünnumarası = Jtextfield2.getText();
				String Stokadedi = JtextField3.getText();
				String ÜrünModeli =(String)jcomboBox1.getSelectedItem();
				String ürünFiyatı = jtextField6.getText();
				try
				{
					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps=con.prepareStatement("insert into veriler values (?,?,?,?,?,?)");
					ps.setString(1, id);
					ps.setString(2, ad);
					ps.setString(3, ürünnumarası);
					ps.setString(4, Stokadedi);
					ps.setString(5, ÜrünModeli);
					ps.setString(6, ürünFiyatı);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null, "Başarılı Kayıt");
					setVisible(false);
					new NewMember().setVisible(true);
				}
				catch (Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
					
				}
				
				
				
				
		
			}
		});
		JButton2.setIcon(new ImageIcon(NewMember.class.getResource("/resimler/save.png")));
		JButton2.setBounds(60, 428, 106, 37);
		panel.add(JButton2);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBackground(SystemColor.textHighlight);
		btnNewButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int a=JOptionPane.showConfirmDialog(null, "Menüye Dönmek İstermisiniz","evet",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{													
					setVisible(false);
					new home().setVisible(true);
				}
					
			}
		});
		btnNewButton.setIcon(new ImageIcon(NewMember.class.getResource("/resimler/exit.png")));
		btnNewButton.setBounds(44, 0, 53, 37);
		panel.add(btnNewButton);
		
		
		
		
		
		
		
		
		
		
		
	}
}
