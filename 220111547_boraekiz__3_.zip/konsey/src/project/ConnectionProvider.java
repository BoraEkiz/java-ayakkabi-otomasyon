package project;
import java.sql.*;




public class ConnectionProvider {
	public static Connection getCon()
	{
	
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:8081/ayakkabı","root","12345");
			return con;
		}
		catch(Exception e)
		{
			return null;
			
		}
	}
		

	

}
